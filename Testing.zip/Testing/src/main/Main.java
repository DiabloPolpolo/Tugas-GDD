package main;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Main extends JFrame {
    private CardLayout cardLayout;
    private JPanel mainPanel;
    private MenuPanel menuPanel;
    private GamePanel gamePanel;
    private String gameMode = "single";

    public Main() {
        setTitle("Tic Tac Toe Neon");
        setSize(450, 550);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        cardLayout = new CardLayout();
        mainPanel = new JPanel(cardLayout);

        menuPanel = new MenuPanel();
        gamePanel = new GamePanel();

        mainPanel.add(menuPanel, "Menu");
        mainPanel.add(gamePanel, "Game");

        add(mainPanel);
        setVisible(true);
    }

    public void setGameMode(String mode) {
        this.gameMode = mode;
    }

    public String getGameMode() {
        return this.gameMode;
    }

    public void showGamePanel() {
        gamePanel.resetGame();
        cardLayout.show(mainPanel, "Game");
    }

    public void showMenuPanel() {
        cardLayout.show(mainPanel, "Menu");
    }

    class MenuPanel extends JPanel {
        public MenuPanel() {
            setLayout(new BorderLayout());
            setBackground(Color.BLACK);

            JLabel title = new JLabel("Tic Tac Toe", SwingConstants.CENTER);
            title.setFont(new Font("Arial", Font.BOLD, 48));
            title.setForeground(Color.CYAN);
            add(title, BorderLayout.NORTH);

            JPanel buttonPanel = new JPanel(new GridLayout(2, 1, 20, 20));
            buttonPanel.setBackground(Color.BLACK);
            buttonPanel.setBorder(BorderFactory.createEmptyBorder(50, 50, 50, 50));

            JButton singleButton = createNeonButton("Single Player");
            JButton multiButton = createNeonButton("Multiplayer");

            singleButton.addActionListener(e -> {
                setGameMode("single");
                showGamePanel();
            });
            multiButton.addActionListener(e -> {
                setGameMode("multi");
                showGamePanel();
            });

            buttonPanel.add(singleButton);
            buttonPanel.add(multiButton);

            add(buttonPanel, BorderLayout.CENTER);
        }

        private JButton createNeonButton(String text) {
            JButton button = new JButton(text);
            button.setFocusPainted(false);
            button.setFont(new Font("Arial", Font.BOLD, 24));
            button.setBackground(Color.BLACK);
            button.setForeground(Color.CYAN);
            button.setBorder(BorderFactory.createLineBorder(Color.CYAN, 3));
            button.setCursor(new Cursor(Cursor.HAND_CURSOR));
            button.addMouseListener(new MouseAdapter() {
                @Override
                public void mouseEntered(MouseEvent e) {
                    button.setForeground(Color.WHITE);
                    button.setBorder(BorderFactory.createLineBorder(Color.WHITE, 3));
                }

                @Override
                public void mouseExited(MouseEvent e) {
                    button.setForeground(Color.CYAN);
                    button.setBorder(BorderFactory.createLineBorder(Color.CYAN, 3));
                }
            });
            return button;
        }
    }

    class GamePanel extends JPanel implements ActionListener {
        private JButton[][] buttons = new JButton[3][3];
        private boolean playerXTurn = true;
        private JLabel statusLabel;
        private int[][] winLine = null;

        public GamePanel() {
            setLayout(new BorderLayout());
            setBackground(Color.BLACK);

            statusLabel = new JLabel("Player X's Turn", SwingConstants.CENTER);
            statusLabel.setFont(new Font("Arial", Font.BOLD, 24));
            statusLabel.setForeground(Color.CYAN);
            add(statusLabel, BorderLayout.NORTH);

            BoardPanel boardPanel = new BoardPanel();
            add(boardPanel, BorderLayout.CENTER);

            JPanel bottomPanel = new JPanel(new BorderLayout());
            bottomPanel.setBackground(Color.BLACK);

            JButton restartButton = createNeonButton("Restart");
            restartButton.addActionListener(e -> resetGame());

            JButton backButton = createNeonButton("Back");
            backButton.addActionListener(e -> showMenuPanel());

            bottomPanel.add(restartButton, BorderLayout.CENTER);
            bottomPanel.add(backButton, BorderLayout.SOUTH);

            add(bottomPanel, BorderLayout.SOUTH);
        }

        private JButton createNeonButton(String text) {
            JButton button = new JButton(text);
            button.setFocusPainted(false);
            button.setFont(new Font("Arial", Font.BOLD, 18));
            button.setBackground(Color.BLACK);
            button.setForeground(Color.CYAN);
            button.setBorder(BorderFactory.createLineBorder(Color.CYAN, 2));
            button.setCursor(new Cursor(Cursor.HAND_CURSOR));
            button.addMouseListener(new MouseAdapter() {
                @Override
                public void mouseEntered(MouseEvent e) {
                    button.setForeground(Color.WHITE);
                    button.setBorder(BorderFactory.createLineBorder(Color.WHITE, 2));
                }

                @Override
                public void mouseExited(MouseEvent e) {
                    button.setForeground(Color.CYAN);
                    button.setBorder(BorderFactory.createLineBorder(Color.CYAN, 2));
                }
            });
            return button;
        }

        @Override
        public void actionPerformed(ActionEvent e) {
            JButton clicked = (JButton) e.getSource();
            if (!clicked.getText().equals("")) return;

            clicked.setText(playerXTurn ? "X" : "O");
            clicked.setEnabled(false);

            if (checkWin()) {
                statusLabel.setText((playerXTurn ? "Player X" : getGameMode().equals("multi") ? "Player O" : "Computer O") + " Wins!");
                disableAllButtons();
                repaint();
                return;
            } else if (isBoardFull()) {
                statusLabel.setText("It's a Draw!");
                return;
            }

            playerXTurn = !playerXTurn;

            if (!playerXTurn && getGameMode().equals("single")) {
                statusLabel.setText("Computer O's Turn...");
                Timer timer = new Timer(500, evt -> {
                    computerMove();
                    ((Timer) evt.getSource()).stop();
                });
                timer.setRepeats(false);
                timer.start();
            } else {
                statusLabel.setText("Player " + (playerXTurn ? "X" : "O") + "'s Turn");
            }
        }

        private void computerMove() {
            int[] move = findBestMove();
            buttons[move[0]][move[1]].setText("O");
            buttons[move[0]][move[1]].setEnabled(false);

            if (checkWin()) {
                statusLabel.setText("Computer O Wins!");
                disableAllButtons();
            } else if (isBoardFull()) {
                statusLabel.setText("It's a Draw!");
            } else {
                playerXTurn = true;
                statusLabel.setText("Player X's Turn");
            }
            repaint();
        }

        private int[] findBestMove() {
            int bestScore = Integer.MIN_VALUE;
            int[] move = new int[2];

            for (int i = 0; i < 3; i++) {
                for (int j = 0; j < 3; j++) {
                    if (buttons[i][j].getText().equals("")) {
                        buttons[i][j].setText("O");
                        int score = minimax(0, false);
                        buttons[i][j].setText("");
                        if (score > bestScore) {
                            bestScore = score;
                            move[0] = i;
                            move[1] = j;
                        }
                    }
                }
            }
            return move;
        }

        private int minimax(int depth, boolean isMaximizing) {
            if (checkWinMinimax("O")) return 10 - depth;
            if (checkWinMinimax("X")) return depth - 10;
            if (isBoardFull()) return 0;

            if (isMaximizing) {
                int bestScore = Integer.MIN_VALUE;
                for (int i = 0; i < 3; i++) {
                    for (int j = 0; j < 3; j++) {
                        if (buttons[i][j].getText().equals("")) {
                            buttons[i][j].setText("O");
                            int score = minimax(depth + 1, false);
                            buttons[i][j].setText("");
                            bestScore = Math.max(score, bestScore);
                        }
                    }
                }
                return bestScore;
            } else {
                int bestScore = Integer.MAX_VALUE;
                for (int i = 0; i < 3; i++) {
                    for (int j = 0; j < 3; j++) {
                        if (buttons[i][j].getText().equals("")) {
                            buttons[i][j].setText("X");
                            int score = minimax(depth + 1, true);
                            buttons[i][j].setText("");
                            bestScore = Math.min(score, bestScore);
                        }
                    }
                }
                return bestScore;
            }
        }

        private boolean checkWinMinimax(String symbol) {
            for (int i = 0; i < 3; i++) {
                if (symbol.equals(buttons[i][0].getText()) &&
                    symbol.equals(buttons[i][1].getText()) &&
                    symbol.equals(buttons[i][2].getText())) return true;
                if (symbol.equals(buttons[0][i].getText()) &&
                    symbol.equals(buttons[1][i].getText()) &&
                    symbol.equals(buttons[2][i].getText())) return true;
            }
            if (symbol.equals(buttons[0][0].getText()) &&
                symbol.equals(buttons[1][1].getText()) &&
                symbol.equals(buttons[2][2].getText())) return true;
            if (symbol.equals(buttons[0][2].getText()) &&
                symbol.equals(buttons[1][1].getText()) &&
                symbol.equals(buttons[2][0].getText())) return true;
            return false;
        }

        private boolean checkWin() {
            String symbol = playerXTurn ? "X" : "O";
            for (int i = 0; i < 3; i++) {
                if (symbol.equals(buttons[i][0].getText()) &&
                    symbol.equals(buttons[i][1].getText()) &&
                    symbol.equals(buttons[i][2].getText())) {
                    winLine = new int[][]{{i, 0}, {i, 2}};
                    return true;
                }
                if (symbol.equals(buttons[0][i].getText()) &&
                    symbol.equals(buttons[1][i].getText()) &&
                    symbol.equals(buttons[2][i].getText())) {
                    winLine = new int[][]{{0, i}, {2, i}};
                    return true;
                }
            }
            if (symbol.equals(buttons[0][0].getText()) &&
                symbol.equals(buttons[1][1].getText()) &&
                symbol.equals(buttons[2][2].getText())) {
                winLine = new int[][]{{0, 0}, {2, 2}};
                return true;
            }
            if (symbol.equals(buttons[0][2].getText()) &&
                symbol.equals(buttons[1][1].getText()) &&
                symbol.equals(buttons[2][0].getText())) {
                winLine = new int[][]{{0, 2}, {2, 0}};
                return true;
            }
            return false;
        }

        private boolean isBoardFull() {
            for (int i = 0; i < 3; i++)
                for (int j = 0; j < 3; j++)
                    if (buttons[i][j].getText().equals("")) return false;
            return true;
        }

        private void disableAllButtons() {
            for (int i = 0; i < 3; i++)
                for (int j = 0; j < 3; j++)
                    buttons[i][j].setEnabled(false);
        }

        public void resetGame() {
            playerXTurn = true;
            winLine = null;
            statusLabel.setText("Player X's Turn");
            for (int i = 0; i < 3; i++)
                for (int j = 0; j < 3; j++) {
                    buttons[i][j].setText("");
                    buttons[i][j].setEnabled(true);
                }
            repaint();
        }

        class BoardPanel extends JPanel {
            public BoardPanel() {
                setLayout(new GridLayout(3, 3));
                setBackground(Color.BLACK);
                Font font = new Font("Arial", Font.BOLD, 60);
                for (int i = 0; i < 3; i++)
                    for (int j = 0; j < 3; j++) {
                        buttons[i][j] = new JButton("");
                        buttons[i][j].setFont(font);
                        buttons[i][j].setForeground(new Color(255, 105, 180)); // Neon Pink color
                        buttons[i][j].setBackground(Color.BLACK);
                        buttons[i][j].setBorder(BorderFactory.createLineBorder(Color.CYAN, 2));
                        buttons[i][j].addActionListener(GamePanel.this);
                        add(buttons[i][j]);
                    }
            }

            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                if (winLine != null) {
                    Graphics2D g2 = (Graphics2D) g;
                    g2.setColor(Color.PINK);
                    g2.setStroke(new BasicStroke(5));

                    int w = getWidth() / 3;
                    int h = getHeight() / 3;

                    int x1 = winLine[0][1] * w + w / 2;
                    int y1 = winLine[0][0] * h + h / 2;
                    int x2 = winLine[1][1] * w + w / 2;
                    int y2 = winLine[1][0] * h + h / 2;

                    g2.drawLine(x1, y1, x2, y2);
                }
            }
        }
    }

    public static void main(String[] args) {
        new Main();
    }
}
